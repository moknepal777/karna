# Training Docs

## Links

- [OSCAL](https://github.com/finos/common-cloud-controls/blob/main/docs/resources/training/oscal/oscal.md)
- [Markdown Linting and Formatting - End User Guide](./lint_format_user_guide.md)
- [FINOS CCC Primer](./FINOS-CCC-Primer-June-2024.pdf)
