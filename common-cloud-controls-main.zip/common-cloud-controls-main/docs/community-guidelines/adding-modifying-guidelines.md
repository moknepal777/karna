# Adding or Modifying Community Guidelines

This document is a [community guideline].

- New community guidelines or changes to existing ones can be suggested by anyone by raising a PR and notifying the [Community Structure WG] using the mailing list <ccc-structure@lists.finos.org> for consideration.
- Then the members of the [Community Structure WG] should discuss this issue in their WG meetings and approve the PR for it to become a recommendation.

[community guideline]: ./README.md
[Community Structure WG]: ../governance/community-structure.md#working-groups
