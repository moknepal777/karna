# Community Guidelines

Guidelines are formal recommendations to the community provided as structured outputs from the Community Structure [WG]. While these guidelines have not been approved by the [SC] as official community policy, it is strongly advised that each [WG] follow the recommendations.

This directory will contain all guidelines recommended.

[SC]: ../governance/community-structure.md#steering-committee
[WG]: ../governance/community-structure.md#working-groups
